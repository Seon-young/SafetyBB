var name;
var email;
var domain;
var thumbnail;

var href= window.location.href;

var clientId ;
var redirectUrl;


if ( href.indexOf('127') !== -1 ){
	clientId = 'dev (donnot care)';
	redirectUrl = 'http://dev (donnot care)';
}else if ( href.indexOf('mooo.com') !== -1){
	clientId = '894319450086-ce5khhsn163b9219mep0e44mmkr634sq.apps.googleusercontent.com\t  ';
	redirectUrl = 'https://ttttt-1891e.firebaseapp.com/index.html';
}else{
	clientId = 'release';
	redirectUrl = 'http://release';
}

console.log('google client Id   : ' + clientId);
console.log('google redirectUrl : ' + redirectUrl);

hello.init(
		{google: clientId}, 
		{redirect_uri: redirectUrl} 
	);
var accessToken;
function login(){
	hello('google').login({scope: 'email'}).then(function(auth) {
		hello(auth.network).api('/me').then(function(r) {
			console.log(JSON.stringify(auth));
			accessToken = auth.authResponse.access_token;
			console.log(accessToken);
			getGoogleMe();
		});
	});
}
	    
function setDevMode(){
	name 	= 'dev';
	email 	= 'a@a.com';
	domain	= 'a.com';
	thumbnail = 'https://lh3.googleusercontent.com/-XdUIqdMkCWA/AAAAAAAAAAI/AAAAAAAAAAA/4252rscbv5M/photo.jpg?sz=50';
}

function getGoogleMe(){
	hello('google').api('me').then(
			function(json) {
				console.log(JSON.stringify(json));
				name = json.name;
	    		email = json.email;
	    		domain = json.domain;
	    		thumbnail = json.thumbnail;
				console.log('name   : ' + name);
	    		console.log('email  : ' + email);
	    		console.log('domain : ' + domain);
	    		console.log('thumbnail : ' + thumbnail);
	    		loginComplete();
			}, 
			function(e) {
	    		console.log('me error : ' + e.error.message);
	    	});
}
function logout(){
	hello('google').logout().then(
			function() {
				console.log('logout');
			},
			function(e) {
				console.log('Signed out error: ' + e.error.message);
	    	});
}